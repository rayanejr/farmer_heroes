#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include<string.h>
#include<windows.h>

typedef struct joueur {
    char name[20];
    char couleur;
    int id;
}t_joueur;

void regle_jeu();
void auteur();
void debut_jeu(t_joueur*ptjoueur);
void gotoligcol( int lig, int col );
int grille_1();
int grille_2();
int grille_3();
void Permuter_Matrice(int l1,int c1, int l2,int c2,char  **tab);
void Color(int couleurDuTexte, int couleurDeFond);
void sauvegarde();


#endif // HEADER_H_INCLUDED
