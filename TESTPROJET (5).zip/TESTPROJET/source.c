#include"header.h"
/*void sauvegarde(){
    FILE *ptsauvegarde;
    ptsauvegarde= fopen("sauvegarde.txt", "w");

    if(ptsauvegarde==NULL){
        printf("Erreur lors de l'ouverture d'un fichier");
        exit(1);
    }


        ptsauvegardeputc(t_joueur, ptsauvegarde);
    }

    fclose(ptsauvegarde);

    return 0;
}
}*/
void afficheMenu(){
    t_joueur joueur;

    t_joueur*ptjoueur;
    int choix,a;
    char nom;


     //do{
            do{
                printf("\t\t\tbienvenue dans CANDY CRUSH\n\n");
                printf("Menu principal :\tPSEUDO CANDY CRUSH (avec des lettes)\n");
                printf("\nVeuillez entrez votre nom:\n");
                scanf("%s",&nom);
                printf("Bienvenue \n");
                printf("1. JOUER Au 1 ere Niveau\n");
                printf("2. JOUER Au 2eme Niveau\n");
                printf("3. JOUER Au 3 eme Niveau\n");
                printf("4. REGLES DU JEU \n");
                printf("5. AUTEURS DU JEU\n");
                printf("6. QUITTER \n");
                scanf("%d",&choix);
                }while(choix<1||choix>6);


   switch(choix)
    {
        case 1:
            system("cls");
            debut_jeu(&ptjoueur);
            grille_1();
            break;
        case 2:
            system("cls");
            debut_jeu(&ptjoueur);
            grille_2();
            break;
        case 3:
            system("cls");
            debut_jeu(&ptjoueur);
            grille_3();
            break;

        case 4:
            system("cls");
            regle_jeu();
            break;

        case 5:
            system("cls");
            auteur();
            break;


        case 6:
              system("cls");
            printf("Merci d'avoir joue \n\n\n\n\n\n");
            exit(0);

        default :
            system("cls");
            printf("Veuillez resaisir votre choix");
            return 0 ;
            break;

    }
        //}while(choix<1 ||choix>=6);
}

void regle_jeu(){
    printf("Le but du jeu est de realiser les meilleures combinaisons posssibles en un nombre limite de coups, \n avec au moins trois lettres identiques afin de remplir les objectifs \n et de marquer le plus de points possibles.\n");
    afficheMenu();
}
void auteur(){
    int choix1;
    printf("Rayane JERBI\n");
    printf("Youssef MEJAI\n");
    printf("Arthur BENTAR\n");
    printf("Soya DEMBA\n");
    do{
        printf("Tapper 1 pour revenir au menu:");
        scanf("%d",&choix1);
    }while(choix1!=1);
    afficheMenu();
}
void debut_jeu(t_joueur*ptjoueur){
  printf("Veuillez saisir le nom du joueur1:");
    scanf("%s",ptjoueur->name);

    ptjoueur->id = 1;
    ptjoueur->couleur = 'j';
    afficheMenu();
}

void gotoligcol( int lig, int col ){
// ressources
COORD mycoord;

mycoord.X = col;
mycoord.Y = lig;
SetConsoleCursorPosition( GetStdHandle( STD_OUTPUT_HANDLE ), mycoord );
}

/*void remplir_matrice(char mat[n][m]);*/
/*void afficher_matrice(char mat[n][m]);*/

int grille_1(){
   int n=10;
   int m=15;
   char **tab;
   int c1, l1, c2, l2;

 char matrice_1[n][m];
// Initialisation du generateur al�atoire
	srand (time (NULL));
	int i,j,r;


	// Remplissage du tableau
	for(i = 0; i < n; i++)	{
		for(j = 0; j < m; j++){

			r=rand() % 4;
			if(r==0){
                    matrice_1[i][j]= 'S';
                }
                else if(r==1){
                    matrice_1[i][j]= 'O';
                }
                else if(r==2){
                    matrice_1[i][j]= 'F';
                }
                else{
                    matrice_1[i][j]= 'P';
                }
		gotoligcol(5,15);
	}
	}
	/*remplir_matrice(matrice_1);*/
	printf("\nChoix 1:\n\n");
	/*afficher_matrice(matrice_1);*/
		// Affichage du tableau
	for(i = 0; i < n; i++)	{
		for(j = 0; j < m; j++){
			printf("%c\t", matrice_1[i][j]);
		}
		printf("\n");
	}
	Permuter_Matrice(l1,c1, l2, c2, tab);
return 0;
afficheMenu();

 }
int grille_2()
 {
 	int n=10;
    int m=15;

 char matrice_2[n][m];
// Initialisation du generateur al�atoire
	srand (time (NULL));
	int i,j,r;


	// Remplissage du tableau
	for(i = 0; i < n; i++)	{
		for(j = 0; j < m; j++){

		r=rand()%4;
                if(r==0)
                {
                    matrice_2[i][j]= 'S';
                }
                else if(r==1)
                {
                    matrice_2[i][j]= 'F';
                }
                else if(r==2)
                {
                    matrice_2[i][j]= 'O';
                }
                else
                {
                    matrice_2[i][j]= 'P';
                }
		}
	}

	printf("\nChoix 2:\n\n");

		// Affichage du tableau
	for(i = 0; i < n; i++)	{
		for(j = 0; j < m; j++){
			printf("%c\t", matrice_2[i][j]);
		}
		printf("\n");
	}
	afficheMenu();
 	return 0;
 }
 int grille_3()
{
int n=10;
int m=15;

char matrice_3[n][m];
// Initialisation du generateur al�atoire
	srand (time (NULL));
	int i,j,r;


	// Remplissage du tableau
	for(i = 0; i < n; i++)	{
		for(j = 0; j < m; j++){
                r=rand()%4;
                if(r==0)
                {
                    matrice_3[i][j]= 'S';
                }
                else if(r==1)
                {
                    matrice_3[i][j]= 'F';
                }
                else if(r==2)
                {
                    matrice_3[i][j]= 'O';
                }
                else
                {
                    matrice_3[i][j]= 'P';
                }
		}
}

	printf("\nChoix 3:\n\n");

		// Affichage du tableau
	for(i = 0; i < n; i++)	{
		for(j = 0; j < m; j++){
			printf("%c\t", matrice_3[i][j]);
		}
		printf("\n");
	}
	afficheMenu();
  	return 0;
  }

void Permuter_Matrice(int l1,int c1, int l2,int c2,char  **tab)
{

int meilleur_score=0;
int score=0;
int m;
int n;
int choix;
int nb_permutation;

while(nb_permutation!=0) {


	  printf("\nLe nombre de permutation est: %d\n Votre score est de:%i\n votre meilleur score est de :%d\n",nb_permutation,score,meilleur_score);
	  do
	  {

          printf("Veuillez donner le numero de la premiere ligne:\n");
          fflush(stdout);
          scanf("%d",&l1);

      }while(l1>n+1 || l1<1);

    do{

         printf("Veuillez donner le numero de la premiere colonne:\n");
         fflush(stdout);
         scanf("%d",&c1);

    }while(c1>m+1 || c1<1);
  do{

        printf("Veuillez donner le numero de la deuxieme ligne:\n");
        fflush(stdin);
        scanf("%d",&l2);

    }while(l2>n+1 || l2<1 || l2>l1+1 || l2<l1-1);
        if(l1==l2)
        {
              printf("Veuillez donner le numero de la deuxieme colonne:\n");
        	do{
                 fflush(stdout);
                 scanf("%d",&c2);


        	  }while(c2>m+1 || c2<1 || c2>c1+1 || c2==c1 || c2<c1-1);

        }
		else{
        	   c2=c1;
        	   printf("La deuxieme colonne de la case a permuter est: %d",c2);

            }

     nb_permutation-- ;
     score=score+3;
     meilleur_score+=score;
     }
     afficheMenu();
system("pause");
}

void Color(int couleurDuTexte, int couleurDeFond ){
     HANDLE H=GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(H,couleurDeFond*16+couleurDuTexte);
}


