#include"header.h"

int main()
{
    t_joueur joueur;

    t_joueur*ptjoueur;
	srand (time (NULL)); // Initialisation du g�n�rateur al�atoire

	gotoligcol(5,15);
	afficheMenu();

return 0;
}
